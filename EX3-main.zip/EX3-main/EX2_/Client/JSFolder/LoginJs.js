﻿$(document).ready(function(){

    $("#LoginButton").click(postLogin);
 });


 function validateRegistrationForm() {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    const emailRegex = /^((?!\.)[\w\-_.]*[^.])(@\w+)(\.\w+(\.\w+)?[^.\W])$/;
    const passwordRegex=/^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\w\d\s:])([^\s]){4,}$/;

    // Validate if userId, fullName, email, password, and confirmPassword are not empty
    if (email === "" || password === "") {
        alert("Please fill all fields.");
        return false;
    }

    if (!emailRegex.test(email)) {
        alert("Invalid Email!!");
        return false;
    }

    // if (!passwordRegex.test(password)) {
    //     alert("Invalid Password!! password must contain at least 1 number,1 uppercase letters, 1 lowercase letters and 1 special characters like @ # ? *");
    //     return false;
    // }

    return true;
}
 function postLogin(){
   if( validateRegistrationForm()){
        let port = "7230";
        let api = `https://localhost:${port}/api/User/login`;
    
        const login = {
            Id: 0,
            Name: "0",
            Email: $('#email').val(),
            Password: $('#password').val(),
            IsAdmin: true,
            IsActive: true,
        };
        ajaxCall("POST", api, JSON.stringify(login), LoginSCB, LoginECB);


        const loginUser = {
            Id: 0,
            Name: "0",
            IsAdmin: false,
            IsActive: true,
        };

        localStorage.setItem("loggedInUser", JSON.stringify(loginUser));

    }

}

function LoginSCB(response) {
    if(response===0){
        alert("Login has ben successed admin");
        window.location.href = "admin.html";
    }
    if(response===1){
        alert("Login has ben successed");
        window.location.href = "index.html";

    }
    if(response===2){
        alert("Account is not exist");
    }
    // Redirect to home page after successful registration

}

function LoginECB(err) {
    console.log(err);
    alert("Error");
}


//<a href="LoginPage.html">Login</a>








// let port = "7123";

// $(document).ready(function () {
//     $("#email").on("input", function () {
//         var pattern = $(this).attr("pattern");
//         var value = $(this).val();
//         var message = "Please match the requested format:  example123@example.com";
//         this.setCustomValidity(value.match(pattern) ? "" : message);
//     });

//     $("#loginForm").submit(function (e) {
//         e.preventDefault();

//         let api = https://localhost:${port}/api/Users/Login;

//         const loginData = {
//             Id: 0,
//             Name: "0",
//             Email: $('#loginForm #email').val(),
//             Password: $('#loginForm #password').val(),
//             IsAdmin: false,
//             IsActive: true,
//         };

//         ajaxCall("POST", api, JSON.stringify(loginData), loginSuccess, loginError);
//     });
// });

// function loginSuccess(response) {
//     Swal.fire({
//         icon: 'success',
//         title: 'Success!',
//         text: 'Login successful'
//     }).then(() => {
//         // Redirect to home page after successful login
//         window.location.href = "index.html";
//     });
// }

// function loginError(err) {
//     Swal.fire({
//         icon: 'error',
//         title: 'Login Failed',
//         text: err.responseJSON.error
//     });
// }
