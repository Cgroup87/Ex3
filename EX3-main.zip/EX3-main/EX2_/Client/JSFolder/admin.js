﻿$(document).ready(function () {
    console.log("Document is ready and the script is loaded."); // Verify script is loaded

    let port = "7230";
    let api = `https://localhost:${port}/api/Courses`;
    let instructorsApi = `https://localhost:${port}/api/Instructors`; // Adjust this if your API endpoint is different
    let coursesList = [];
    let isAddCourse = false; // Track whether "Add Course" button was used

    getCoursesFromServer(api);

    function getInstructorsFromServer(api) { // Get Instructor List From Server
        $.ajax({
            url: api,
            method: "GET",
            success: getInstructorsSCB,
            error: getInstructorsECB
        });
    }

    function getInstructorsSCB(instructorsList) {
        console.log(instructorsList);
        showInstructorsDatalist(instructorsList); // Populate datalist with instructors
    }

    function getInstructorsECB(xhr, status, error) {
        console.log(error);
    }

    function getCoursesFromServer(api) {
        $.ajax({
            url: api,
            method: "GET",
            success: getCoursesSCB,
            error: getCoursesECB
        });
    }

    function getCoursesSCB(courses) {
        console.log(courses);
        coursesList = courses;
        displayCourses(coursesList);
        showCoursesDatalist(coursesList);
    }

    function getCoursesECB(xhr, status, error) {
        console.log(error);
    }

    function displayCourses(courses) {
        const courseList = $('#courses-container');
        courseList.empty(); // Clear existing content

        // Check if courses is an array
        if (Array.isArray(courses)) {
            // Iterate over the array of courses
            courses.forEach(course => {
                displayCourse(course);
            });
        } else {
            // If courses is not an array (i.e., a single course)
            displayCourse(courses);
        }
    }

    function displayCourse(course) {
        // Define courseItem HTML
        const courseItem = `
        <div class="course">
            <div class="image_course"><img src="${course.imageReference}" alt="${course.title}"></div>
            <div class="title_course"><h2 class="course-title"><a href="${course.url}" target="_blank">${course.title}</a></h2></div>
            <div class="course-details">
                <p>Rating: ${course.rating}</p>
                <p>Reviews: ${course.numberOfReviews}</p>
                <p>Last Updated: ${course.lastUpdate}</p>
                <p>Duration: ${course.duration}</p>
                <p> - - - - - - - - - - - - - - -</p>
                <p>Course Id: ${course.id}</p>
                <p>Instructor Id: ${course.instructorsId}</p>
                <p>Image Url: ${course.imageReference}</p>
            </div>
        </div>
    `;

        // Append courseItem to courseList
        $('#courses-container').append(courseItem);
    }

    function showCoursesDatalist(coursesList) {
        const datalist = $('#courses');
        datalist.empty();
        coursesList.forEach(course => {
            const option = `<option value="${course.title}" data-id="${course.id}"></option>`;
            datalist.append(option);
        });
    }

    function showInstructorsDatalist(instructorsList) {
        const datalist = $('#instructors');
        datalist.empty();
        instructorsList.forEach(instructor => {
            const option = `<option value="${instructor.id}"></option>`;
            datalist.append(option);
        });
        $("#courseInstructorId").attr("list", "instructors");
    }

    $("#courseSelect").on('input', function () {
        const selectedCourseTitle = $(this).val();
        const selectedCourse = $('#courses').find(`option[value="${selectedCourseTitle}"]`).data('id');
        let course;

        if (selectedCourse) {
            course = coursesList.find(course => course.id === selectedCourse);
        }

        if (course) {
            displayCourses([course]);
            $("#courseId").val(course.id);
            $("#courseTitle").val(course.title);
            $("#courseUrl").val(course.url);
            $("#courseDuration").val(course.duration);
            $("#courseRating").val(course.rating);
            $("#courseNumReviews").val(course.numberOfReviews);
            $("#courseInstructorId").val(course.instructorsId);
            $("#courseImage").val(course.imageReference);
            $("#editCourseForm").show();

            // Disable certain fields
            $("#courseId").prop('disabled', true);
            $("#courseRating").prop('disabled', true);
            $("#courseNumReviews").prop('disabled', true);
            $("#courseInstructorId").prop('disabled', true);

        } else {
            // If the selected course is not found, display all courses from the original list
            displayCourses(coursesList);
            $("#editCourseForm").hide();
        }

        isAddCourse = false; // Reset flag as we are selecting a course, not adding a new one
    });

    $("#addCourseBtn").click(function () {
        getInstructorsFromServer(instructorsApi); // Fetch instructors and populate datalist
        $("#editCourseForm").show();
        // Clear form fields for new course entry
        $("#courseId").val("");
        $("#courseTitle").val("");
        $("#courseUrl").val("");
        $("#courseDuration").val("");
        $("#courseRating").val("0");
        $("#courseNumReviews").val("0");
        $("#courseInstructorId").val("");
        $("#courseImage").val("");
        $("#courseSelect").val("");

        // Enable all form fields
        $("#courseId").prop('disabled', false);
        $("#courseInstructorId").prop('disabled', false);
        displayCourses(coursesList);

        isAddCourse = true; // Set flag as we are adding a new course
    });

    $("#closeFormBtn").click(function () {
        $("#editCourseForm").hide();
        $("#courseSelect").val("");
        displayCourses(coursesList);
    });

    $("#editCourseForm").submit(async function (event) {
        event.preventDefault();

        const urlRegex = /^https:\/\/(?:www\.)?[\w\-]+(\.[\w\-]+)*\.com([\/\w\-\.]*)*\/?$/;
        const imageUrlRegex = /^https:\/\/(?:www\.)?[\w\-]+(\.[\w\-]+)*\.com([\/\w\-\.]*)*\.(jpg|jpeg|png|gif)$/i;
        const imageFileRegex = /\.(jpg|jpeg|png|gif)$/i;

        const courseId = $("#courseId").val();
        const courseUrl = $("#courseUrl").val();
        const courseImage = $("#courseImage").val();

        const today = new Date();
        const day = String(today.getDate()).padStart(2, '0');
        const month = String(today.getMonth() + 1).padStart(2, '0'); 
        const year = today.getFullYear();

        const formattedDate = `${day}/${month}/${year}`;

        const updatedCourse = {
            id: courseId,
            title: $("#courseTitle").val(),
            url: courseUrl,
            rating: $("#courseRating").val(),
            numberOfReviews: $("#courseNumReviews").val(),
            instructorsId: $("#courseInstructorId").val(),
            duration: $("#courseDuration").val(),
            lastUpdate: formattedDate,
            imageReference: courseImage || 'defaultImageURL' 
        };


        let invalid = false;

        // Validate Course URL
        if (!urlRegex.test(courseUrl)) {
            $("#courseUrlError").text("Invalid URL need to be-> https:___www.___.com").show();
            invalid = true;
        } else {
            $("#courseUrlError").hide();
        }

        // Validate Image URL
        if (courseImage && !imageUrlRegex.test(courseImage)) {
            $("#courseImageUrlError").text("Invalid Image URL need to be-> https:___.com/___.jpg/jpeg/png/gif").show();
            invalid = true;
        } else {
            $("#courseImageUrlError").hide();
        }

        if (invalid) {
            return;
        }

        try {
            if (isAddCourse) {
                // Validate if courseId already exists
                for (let course of coursesList) {
                    if (parseInt(course.id) === parseInt(courseId)) {
                        $("#courseIdError").text("Course ID already exists").show();
                        return; // Stop form submission
                    }
                }
                $("#courseIdError").hide(); // Hide error message if validation passes

                console.log(updatedCourse);
                await $.ajax({
                    url: api,
                    method: "POST",
                    data: JSON.stringify(updatedCourse), 
                    contentType: "application/json",
                    success: postCoursesSCB,
                    error: postCoursesECB
                });
               
            } else {
                await $.ajax({
                    url: api,
                    method: "PUT",
                    data: JSON.stringify(updatedCourse), 
                    contentType: "application/json",
                    success: putCoursesSCB,
                    error: putCoursesECB
                });

            }

            getCoursesFromServer(api);
        } catch (error) {
            console.error(error);
            alert(`Failed to ${isAddCourse ? 'add' : 'update'} course`);
        }
    });


    $("#postBtn").click(function () {
        coursesPostToServer(api);
    });

    // Restrict input to datalist options for courseInstructorId
    $("#courseInstructorId").on('input', function () {
        const inputVal = $(this).val();
        const options = $('#instructors option').map(function () { return this.value; }).get();
        if (!options.includes(inputVal)) {
            $(this).val('');
        }
    });
});

async function coursesPostToServer(api) {
    let courses = await $.getJSON("../DataFolder/Course.json");
    let coursesEdited = courses.map(course => ({
        id: course.id,
        title: course.title,
        url: "https://www.udemy.com" + course.url,
        rating: course.rating,
        numberOfReviews: course.num_reviews,
        instructorsId: course.instructors_id,
        imageReference: course.image,
        duration: course.duration.match(/[\d.]+/)[0],
        lastUpdate: course.last_update_date
    }));

    console.log(coursesEdited);

    for (let course of coursesEdited) {
        await $.ajax({
            url: api,
            method: "POST",
            data: JSON.stringify(course),
            contentType: "application/json",
            success: postAllCoursesSCB,
            error: postAllCoursesECB
        });
    }
    alert("Done");

    document.getElementById("postBtn").disabled = true;
    alert("The button will be enabled");
}

function postAllCoursesSCB(response) {
    console.log(response);

}

function postAllCoursesECB(xhr, status, error) {
    console.log(error);
}


function postCoursesSCB(response) {
    console.log(response);
    if (response == true) {
        alert('Course added successfully');
    }
    else {
        alert('Course not added');
    }
}

function postCoursesECB(xhr, status, error) {
    console.log(error);
}

function putCoursesSCB(response) {
    console.log(response);
    if (response == true) {
        alert('Course updated successfully');
    }
    else {
        alert('Course not updated');
    }
}

function putCoursesECB(xhr, status, error) {
    console.log(error);
}