﻿using hw1.BL;
using Microsoft.AspNetCore.Mvc;
using server.BL;
using System.Diagnostics.Metrics;

namespace server.BL
{
    public class User
    {
        int id;
        string name;
        string email;
        string password;
        bool isAdmin;
        bool isActive;
        static List<Course> myCourses = new List<Course>();
        static List<User> usersList = new List<User>();

        public int Id { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }
        public string Password { get => password; set => password = value; }
        public bool IsAdmin { get => isAdmin; set => isAdmin = value; }
        public bool IsActive { get => isActive; set => isActive = value; }
        public List<Course> MyCourses { get => myCourses; set => myCourses = value; }

        public User()
        {
            myCourses = new List<Course>();
            if (usersList.Count == 0)
            {
                usersList.Add(new User(1, "admin", "admin@admin.com", "admin", true, true));
            }
        }

        public User(int id, string name, string email, string password, bool isAdmin, bool isActive)
        {
            this.Id = id;
            this.Name = name;
            this.Email = email;
            this.Password = password;
            this.IsAdmin = isAdmin;
            this.IsActive = isActive;
            this.MyCourses = new List<Course>();
        }

        public List<User> Read()
        {
            return usersList;
        }

        public bool Registration()
        {
            foreach (User user in usersList)
            {
                if (user.password == this.password || user.email == this.email || user.Id == this.Id)
                {
                    return false;
                }
            }
            usersList.Add(this);
            IsAdmin = false;
            isActive = true;
            return true;
        }
        public int Login(User userLoginInput) /// method to check if the admin or the user or no one of them has login to his account
        {
            int ExistAccount = 0;// we declared an int variable to help us chouse one condition of the 3 conditions 
            foreach (User user in usersList)
            {
                if ("admin" == userLoginInput.password && "admin@admin.com" == userLoginInput.email)// if the user is the admin it will still 0
                {
                    id = user.id;
                    name = user.name;
                    isAdmin = user.IsAdmin;
                    isActive = user.isActive;
                    return ExistAccount;
                }

                if (user.password == userLoginInput.password && user.email == userLoginInput.email)// if it is a normal user it will be 1
                {
                    id = user.id;
                    name = user.name;
                    isAdmin = user.IsAdmin;
                    isActive = user.isActive;
                    return ExistAccount + 1;
                }
            }
            return ExistAccount + 2;// else it will be 3
        }


        public void UserLogout(string email, uint id)
        {
            var user = usersList.FirstOrDefault(user => user.Email.ToLower() == email.ToLower() || user.Id == id);
            if (user != null)
            {
                user.IsActive = false;
            }
        }
        public static User GetUserById(string email)
        {

            foreach (User user in usersList)
            {
                if (user.Email == email)
                {
                    user.isActive = true;
                    return user;
                }
            }
            return null;
        }

        public static bool AddMyCourse(Course addCourse)
        {
            foreach (Course course in myCourses)
            {
                if (course.Id == addCourse.Id || course.Title.ToLower() == addCourse.Title.ToLower())
                {
                    return false;
                }
            }
            myCourses.Add(addCourse);
            return true;
        }


        public static List<Course> ReadMyCourses()
        {
            return myCourses;
        }

        public Course GetMyCourseById(uint id)
        {
            foreach (Course course in myCourses)
            {
                if (course.Id == id)
                {
                    return course;
                }
            }
            return null;
        }

        public static List<Course> GetMyCourseByDurationRange(double min_duration, double max_duration)
        {
            List<Course> durationInRange = new List<Course>();
            foreach (Course course in myCourses)
            {
                if (min_duration <= course.Duration && max_duration >= course.Duration)
                {
                    durationInRange.Add(course);
                }
            }
            return durationInRange;
        }

        public static List<Course> GetMyCourseByRatingRange(double min_rating, double max_rating)
        {
            List<Course> ratingInRange = new List<Course>();
            foreach (Course course in myCourses)
            {
                if (min_rating <= course.Rating && max_rating >= course.Rating)
                {
                    ratingInRange.Add(course);
                }
            }
            return ratingInRange;
        }

        public static List<Course> DeleteMyCourseById(int id_delete)
        {
            for (int i = myCourses.Count - 1; i >= 0; i--)
            {
                if (myCourses[i].Id == id_delete)
                {
                    myCourses.RemoveAt(i);
                    return myCourses;
                }
            }
            throw new ArgumentException("Not Found a course with such id");
        }
    }
}