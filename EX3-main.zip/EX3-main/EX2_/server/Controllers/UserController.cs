﻿using hw1.BL;
using Microsoft.AspNetCore.Mvc;
using server.BL;
using System.Collections.Generic;

namespace hw1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        //// GET: api/<UserController>
        [HttpGet]
        public IEnumerable<User> Get()
        {
            User user = new User();

            return user.Read();
        }

        // GET api/<UserController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {

            return "value";
        }

        // POST api/<UserController>
        [HttpPost("register")]
        public bool Post([FromBody] User value)
        {
            return value.Registration();
        }

        [HttpPost("login")]
        public int Post_Login([FromBody] User value)
        {
            return value.Login(value);
        }

        [HttpPost("addCourse")]
        public bool AddCourseToUser([FromBody] Course course)
        {
 
            return server.BL.User.AddMyCourse(course);
        }

        // PUT api/<UserController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

 

        [HttpGet("GetMyCourses")]
        public IEnumerable<Course> GetMyCourses()
        {
            return server.BL.User.ReadMyCourses();
        }


        [HttpGet("SearchByDuration")] // this uses the QueryString
        public IEnumerable<Course> GetByDurationRange(float minDuration, float maxDuration)
        {
            return server.BL.User.GetMyCourseByDurationRange(minDuration, maxDuration);
        }


        [HttpGet("searchByRating/Minimum rating/{minRating}/Maximum rating/{maxRating}")] // this uses resource routing
        public IEnumerable<Course> GetByRatingRange(double minRating, double maxRating)
        {
            return server.BL.User.GetMyCourseByRatingRange(minRating, maxRating);
        }

        [HttpDelete("DeleteCourseById/id/{id}")]
        public IEnumerable<Course> DeleteById(int id)
        {
            return server.BL.User.DeleteMyCourseById(id);
        }
    }

}
